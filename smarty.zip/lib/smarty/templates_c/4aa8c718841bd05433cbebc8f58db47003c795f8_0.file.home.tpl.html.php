<?php
/* Smarty version 3.1.30, created on 2017-08-31 07:28:39
  from "D:\dev\smarty\views\home.tpl.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59a79e872001d5_05555633',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4aa8c718841bd05433cbebc8f58db47003c795f8' => 
    array (
      0 => 'D:\\dev\\smarty\\views\\home.tpl.html',
      1 => 1504157275,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59a79e872001d5_05555633 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1>This is Home View</h1><?php }
}
