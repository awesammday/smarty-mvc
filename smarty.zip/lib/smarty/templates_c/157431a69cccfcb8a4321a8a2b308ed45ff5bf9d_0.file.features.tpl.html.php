<?php
/* Smarty version 3.1.30, created on 2017-08-31 10:09:28
  from "D:\dev\smarty\views\public\features.tpl.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59a7c438260ff3_90302379',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '157431a69cccfcb8a4321a8a2b308ed45ff5bf9d' => 
    array (
      0 => 'D:\\dev\\smarty\\views\\public\\features.tpl.html',
      1 => 1504166967,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59a7c438260ff3_90302379 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">Features</h1>
        <p class="lead text-muted">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
        <p>
        <a href="#" class="btn btn-primary">Main call to action</a>
        <a href="#" class="btn btn-secondary">Secondary action</a>
        </p>
    </div>
</section>

<div class="album text-muted">
    <div class="container">

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>                
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>                
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>                
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>                
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img data-src="holder.js/100px280/thumb" alt="Card image cap">
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
                <br>                
            </div>
    

            
           
        </div>

    </div>
</div><?php }
}
