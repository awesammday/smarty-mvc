<?php
/* Smarty version 3.1.30, created on 2017-08-31 09:51:36
  from "D:\dev\smarty\views\components\footer.tpl.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59a7c008c7bc68_02030813',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '600da928d76739ecdaba4793f4cae6edb883adac' => 
    array (
      0 => 'D:\\dev\\smarty\\views\\components\\footer.tpl.html',
      1 => 1504165896,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59a7c008c7bc68_02030813 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
    <hr>
    <footer class="footer">
        <p>&copy; Company 2017</p>
    </footer>
</div><?php }
}
