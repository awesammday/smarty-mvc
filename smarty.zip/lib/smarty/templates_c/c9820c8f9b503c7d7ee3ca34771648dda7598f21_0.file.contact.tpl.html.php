<?php
/* Smarty version 3.1.30, created on 2017-08-31 10:13:55
  from "D:\dev\smarty\views\public\contact.tpl.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59a7c543d84e88_98078955',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c9820c8f9b503c7d7ee3ca34771648dda7598f21' => 
    array (
      0 => 'D:\\dev\\smarty\\views\\public\\contact.tpl.html',
      1 => 1504167235,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59a7c543d84e88_98078955 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">

    <div class="inner cover">
        <br>
        <h1 class="cover-heading">Contact page.</h1>
        <p class="lead">Contact page is one page template that shows the contact information and other contact details of a person.</p>
        <p class="lead">
            <a href="#" class="btn btn-lg btn-secondary">Learn more</a>
        </p>
    </div>
</div><?php }
}
