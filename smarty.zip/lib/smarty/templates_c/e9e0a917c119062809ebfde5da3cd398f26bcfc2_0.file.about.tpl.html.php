<?php
/* Smarty version 3.1.30, created on 2017-08-31 07:51:14
  from "D:\dev\smarty\views\public\about.tpl.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59a7a3d2897b91_13950747',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e9e0a917c119062809ebfde5da3cd398f26bcfc2' => 
    array (
      0 => 'D:\\dev\\smarty\\views\\public\\about.tpl.html',
      1 => 1504158349,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59a7a3d2897b91_13950747 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1>This is About page</h1><?php }
}
