<?php
    $template_config = array(
        'template_dir' => 'views/',
        'compile_dir' => 'lib/smarty/templates_c/',
        'cache_dir' => 'lib/smarty/cache/',
        'config_dir' => 'lib/smarty/config/',
        'controller_dir' => 'controllers/'
    );
?>