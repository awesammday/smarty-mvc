<?php
    $route['home'] = 'Main/index';
    $route['features'] = 'Main/features';
    $route['contact'] = 'Main/contact';
    $route['default_controller'] = 'Main';
?>